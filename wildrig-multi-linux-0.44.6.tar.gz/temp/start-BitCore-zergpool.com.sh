#!/bin/bash

while true
do
./wildrig-multi --algo megabtx --url stratum+tcp://megabtx.mine.zergpool.com:3557 --user sY7v3ieNguMPRd8XkzGdUtASDZFrCvdAmn --pass c=BTX,mc=BTX
sleep 5
done

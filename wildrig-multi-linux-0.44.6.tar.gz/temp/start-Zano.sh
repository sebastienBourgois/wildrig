#!/bin/bash

while true
do
./wildrig-multi --algo progpowz --url stratum+tcp://zano.luckypool.io:8877 --worker test --user ZxCPRpCsd9U1MtfoVyixVe92abHtwxe4GXfq6yLdcGWiK76kzUy9v9JS2dShrcMAbacEwcHaVBikb2qYboPdH1HY1kfZjarZq --pass x
sleep 5
done
